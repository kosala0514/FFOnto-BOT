# Routing and CQ-selection evaluation

Held-out questions: 1001  (KG: 711, RAG: 290); model qwen2.5:14b; 1.4 s/question

| Metric | Value (95 % CI) |
|---|---|
| Routing accuracy | 0.980 [0.971, 0.988] (n=1001) |
| Routing macro-F1 | 0.976 |
| CQ-selection accuracy (KG questions) | 0.790 [0.762, 0.823] (n=711) |
| CQ-selection macro-F1 | 0.786 |

## Routing per class
| Class | P | R | F1 | support |
|---|---|---|---|---|
| chitchat | 0.000 | 0.000 | 0.000 | 0 |
| kg | 0.990 | 0.983 | 0.987 | 711 |
| rag | 0.959 | 0.972 | 0.966 | 290 |

## CQ selection per class
| CQ | P | R | F1 | support |
|---|---|---|---|---|
| CQ01 | 1.000 | 1.000 | 1.000 | 7 |
| CQ02 | 0.857 | 1.000 | 0.923 | 24 |
| CQ03 | 1.000 | 0.889 | 0.941 | 9 |
| CQ04 | 0.800 | 0.667 | 0.727 | 6 |
| CQ05 | 0.818 | 0.692 | 0.750 | 13 |
| CQ06 | 1.000 | 1.000 | 1.000 | 10 |
| CQ07 | 1.000 | 0.571 | 0.727 | 7 |
| CQ08 | 0.846 | 0.786 | 0.815 | 14 |
| CQ09 | 1.000 | 0.765 | 0.867 | 17 |
| CQ10 | 0.750 | 0.900 | 0.818 | 10 |
| CQ11 | 0.625 | 0.500 | 0.556 | 10 |
| CQ12 | 0.733 | 0.611 | 0.667 | 18 |
| CQ13 | 0.700 | 0.636 | 0.667 | 11 |
| CQ14 | 0.667 | 0.867 | 0.754 | 30 |
| CQ15 | 0.529 | 0.818 | 0.643 | 11 |
| CQ16 | 0.795 | 0.795 | 0.795 | 39 |
| CQ17 | 1.000 | 1.000 | 1.000 | 18 |
| CQ18 | 0.778 | 0.803 | 0.790 | 61 |
| CQ19 | 0.898 | 0.746 | 0.815 | 59 |
| CQ20 | 0.824 | 0.782 | 0.803 | 78 |
| CQ21 | 0.444 | 0.857 | 0.585 | 14 |
| CQ22 | 0.909 | 0.735 | 0.813 | 68 |
| CQ23 | 0.812 | 0.812 | 0.812 | 16 |
| CQ24 | 0.943 | 0.806 | 0.870 | 124 |
| CQ25 | 1.000 | 0.300 | 0.462 | 10 |
| CQ26 | 0.774 | 0.889 | 0.828 | 27 |

## Most frequent CQ confusions (gold -> predicted)
Check these by hand: some are labelling errors in the silver labels, not model errors.

- CQ19 -> CQ18: 9
- CQ22 -> CQ14: 8
- CQ22 -> CQ20: 6
- CQ24 -> CQ21: 5
- CQ20 -> CQ21: 4
- CQ24 -> CQ26: 4
- CQ20 -> CQ18: 4
- CQ12 -> CQ15: 4
- CQ24 -> CQ10: 3
- CQ19 -> CQ16: 3
- CQ16 -> CQ19: 3
- CQ18 -> CQ16: 3
- CQ16 -> CQ24: 3
- CQ14 -> NONE: 3
- CQ19 -> CQ21: 3