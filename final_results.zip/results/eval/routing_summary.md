# Routing and CQ-selection evaluation

Held-out questions: 1001  (KG: 711, RAG: 290); model qwen2.5:14b; 1.3 s/question

| Metric | Value (95 % CI) |
|---|---|
| Routing accuracy | 0.970 [0.960, 0.981] (n=1001) |
| Routing macro-F1 | 0.970 |
| CQ-selection accuracy (KG questions) | 0.543 [0.506, 0.582] (n=711) |
| CQ-selection macro-F1 | 0.658 |

## Routing per class
| Class | P | R | F1 | support |
|---|---|---|---|---|
| chitchat | 0.000 | 0.000 | 0.000 | 0 |
| kg | 0.993 | 0.969 | 0.981 | 711 |
| rag | 0.946 | 0.972 | 0.959 | 290 |

## CQ selection per class
| CQ | P | R | F1 | support |
|---|---|---|---|---|
| CQ01 | 1.000 | 1.000 | 1.000 | 7 |
| CQ02 | 0.846 | 0.917 | 0.880 | 24 |
| CQ03 | 1.000 | 0.778 | 0.875 | 9 |
| CQ04 | 0.571 | 0.667 | 0.615 | 6 |
| CQ05 | 0.818 | 0.692 | 0.750 | 13 |
| CQ06 | 0.900 | 0.900 | 0.900 | 10 |
| CQ07 | 1.000 | 0.571 | 0.727 | 7 |
| CQ08 | 0.923 | 0.857 | 0.889 | 14 |
| CQ09 | 1.000 | 0.706 | 0.828 | 17 |
| CQ10 | 0.625 | 1.000 | 0.769 | 10 |
| CQ11 | 0.583 | 0.700 | 0.636 | 10 |
| CQ12 | 0.611 | 0.611 | 0.611 | 18 |
| CQ13 | 0.333 | 0.545 | 0.414 | 11 |
| CQ14 | 0.333 | 0.833 | 0.476 | 30 |
| CQ15 | 0.333 | 0.818 | 0.474 | 11 |
| CQ16 | 0.460 | 0.744 | 0.569 | 39 |
| CQ17 | 0.727 | 0.889 | 0.800 | 18 |
| CQ18 | 0.540 | 0.557 | 0.548 | 61 |
| CQ19 | 0.727 | 0.407 | 0.522 | 59 |
| CQ20 | 0.795 | 0.397 | 0.530 | 78 |
| CQ21 | 0.417 | 0.714 | 0.526 | 14 |
| CQ22 | 0.909 | 0.294 | 0.444 | 68 |
| CQ23 | 0.818 | 0.562 | 0.667 | 16 |
| CQ24 | 0.978 | 0.355 | 0.521 | 124 |
| CQ25 | 1.000 | 0.500 | 0.667 | 10 |
| CQ26 | 0.667 | 0.370 | 0.476 | 27 |

## Most frequent CQ confusions (gold -> predicted)
Check these by hand: some are labelling errors in the silver labels, not model errors.

- CQ22 -> CQ14: 27
- CQ19 -> CQ18: 22
- CQ20 -> NONE: 20
- CQ18 -> CQ16: 15
- CQ24 -> CQ14: 14
- CQ22 -> NONE: 12
- CQ24 -> NONE: 11
- CQ24 -> (not kg): 11
- CQ20 -> CQ16: 10
- CQ24 -> CQ13: 9
- CQ24 -> CQ15: 8
- CQ26 -> (not kg): 7
- CQ24 -> CQ10: 6
- CQ24 -> CQ21: 6
- CQ16 -> CQ19: 6