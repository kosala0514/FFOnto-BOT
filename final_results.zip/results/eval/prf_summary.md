# Precision, recall and F1

## Routing (kg / rag / chitchat)
n = 1001

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| kg | 0.990 | 0.983 | 0.987 | 711 |
| rag | 0.959 | 0.972 | 0.966 | 290 |
| **macro** | 0.975 | 0.978 | 0.976 | 1001 |
| **micro** (= accuracy) | 0.980 | 0.980 | 0.980 | 1001 |

## CQ selection (knowledge-graph questions)
n = 711

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| CQ01 | 1.000 | 1.000 | 1.000 | 7 |
| CQ02 | 0.857 | 1.000 | 0.923 | 24 |
| CQ03 | 1.000 | 0.889 | 0.941 | 9 |
| CQ04 | 0.800 | 0.667 | 0.727 | 6 |
| CQ05 | 0.818 | 0.692 | 0.750 | 13 |
| CQ06 | 1.000 | 1.000 | 1.000 | 10 |
| CQ07 | 1.000 | 0.571 | 0.727 | 7 |
| CQ08 | 0.846 | 0.786 | 0.815 | 14 |
| CQ09 | 1.000 | 0.765 | 0.867 | 17 |
| CQ10 | 0.750 | 0.900 | 0.818 | 10 |
| CQ11 | 0.625 | 0.500 | 0.556 | 10 |
| CQ12 | 0.733 | 0.611 | 0.667 | 18 |
| CQ13 | 0.700 | 0.636 | 0.667 | 11 |
| CQ14 | 0.667 | 0.867 | 0.754 | 30 |
| CQ15 | 0.529 | 0.818 | 0.643 | 11 |
| CQ16 | 0.795 | 0.795 | 0.795 | 39 |
| CQ17 | 1.000 | 1.000 | 1.000 | 18 |
| CQ18 | 0.778 | 0.803 | 0.790 | 61 |
| CQ19 | 0.898 | 0.746 | 0.815 | 59 |
| CQ20 | 0.824 | 0.782 | 0.803 | 78 |
| CQ21 | 0.444 | 0.857 | 0.585 | 14 |
| CQ22 | 0.909 | 0.735 | 0.813 | 68 |
| CQ23 | 0.812 | 0.812 | 0.812 | 16 |
| CQ24 | 0.943 | 0.806 | 0.870 | 124 |
| CQ25 | 1.000 | 0.300 | 0.462 | 10 |
| CQ26 | 0.774 | 0.889 | 0.828 | 27 |
| **macro** | 0.827 | 0.778 | 0.786 | 711 |
| **micro** (= accuracy) | 0.790 | 0.790 | 0.790 | 711 |

## End-to-end: cq
n = 47 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Retrieval, macro (mean per question) | 0.904 | 0.888 | 0.894 | 47 |
| Retrieval, micro (pooled TP=667, FP=20, FN=73) | 0.971 | 0.901 | 0.935 | 47 |
| Answer tokens vs reference (macro) | 0.295 | 0.439 | 0.328 | 47 |

Yes/no answers (cq): no 9, yes 7  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 8, no 8. Majority baseline (always 'yes'): accuracy 0.500

## Yes/no questions (cq)
n = 16

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.778 | 0.875 | 0.824 | 8 |
| yes | 0.857 | 0.750 | 0.800 | 8 |
| **macro** | 0.817 | 0.812 | 0.812 | 16 |
| **micro** (= accuracy) | 0.812 | 0.812 | 0.812 | 16 |

## Yes/no questions about images (cq)
n = 6

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.500 | 1.000 | 0.667 | 1 |
| yes | 1.000 | 0.800 | 0.889 | 5 |
| **macro** | 0.750 | 0.900 | 0.778 | 6 |
| **micro** (= accuracy) | 0.833 | 0.833 | 0.833 | 6 |

## End-to-end: cq_fusion
n = 47 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Retrieval, macro (mean per question) | 0.904 | 0.888 | 0.894 | 47 |
| Retrieval, micro (pooled TP=667, FP=20, FN=73) | 0.971 | 0.901 | 0.935 | 47 |
| Answer tokens vs reference (macro) | 0.301 | 0.449 | 0.336 | 47 |

Yes/no answers (cq_fusion): no 9, yes 7  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 8, no 8. Majority baseline (always 'yes'): accuracy 0.500

## Yes/no questions (cq_fusion)
n = 16

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.778 | 0.875 | 0.824 | 8 |
| yes | 0.857 | 0.750 | 0.800 | 8 |
| **macro** | 0.817 | 0.812 | 0.812 | 16 |
| **micro** (= accuracy) | 0.812 | 0.812 | 0.812 | 16 |

## Yes/no questions about images (cq_fusion)
n = 6

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.500 | 1.000 | 0.667 | 1 |
| yes | 1.000 | 0.800 | 0.889 | 5 |
| **macro** | 0.750 | 0.900 | 0.778 | 6 |
| **micro** (= accuracy) | 0.833 | 0.833 | 0.833 | 6 |

## End-to-end: cq_vlm
n = 47 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Retrieval, macro (mean per question) | 0.904 | 0.888 | 0.894 | 47 |
| Retrieval, micro (pooled TP=667, FP=20, FN=73) | 0.971 | 0.901 | 0.935 | 47 |
| Answer tokens vs reference (macro) | 0.296 | 0.452 | 0.332 | 47 |

Yes/no answers (cq_vlm): no 9, yes 7  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 8, no 8. Majority baseline (always 'yes'): accuracy 0.500

## Yes/no questions (cq_vlm)
n = 16

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.778 | 0.875 | 0.824 | 8 |
| yes | 0.857 | 0.750 | 0.800 | 8 |
| **macro** | 0.817 | 0.812 | 0.812 | 16 |
| **micro** (= accuracy) | 0.812 | 0.812 | 0.812 | 16 |

## Yes/no questions about images (cq_vlm)
n = 6

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.500 | 1.000 | 0.667 | 1 |
| yes | 1.000 | 0.800 | 0.889 | 5 |
| **macro** | 0.750 | 0.900 | 0.778 | 6 |
| **micro** (= accuracy) | 0.833 | 0.833 | 0.833 | 6 |

## End-to-end: vlm
n = 47 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Answer tokens vs reference (macro) | 0.180 | 0.053 | 0.070 | 47 |
**38 of 47 answers ended in an error** (a failed generated query is an error too). Most frequent: 38 x no local image for this record (not an image question, or set IMAGES_D


Yes/no answers (vlm): error 10, yes 4, no 2  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 8, no 8. Majority baseline (always 'yes'): accuracy 0.500

## Yes/no questions (vlm)
n = 16

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.500 | 0.125 | 0.200 | 8 |
| yes | 1.000 | 0.500 | 0.667 | 8 |
| **macro** | 0.750 | 0.312 | 0.433 | 16 |
| **micro** (= accuracy) | 0.312 | 0.312 | 0.312 | 16 |

## Yes/no questions about images (vlm)
n = 6

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.500 | 1.000 | 0.667 | 1 |
| yes | 1.000 | 0.800 | 0.889 | 5 |
| **macro** | 0.750 | 0.900 | 0.778 | 6 |
| **micro** (= accuracy) | 0.833 | 0.833 | 0.833 | 6 |

## End-to-end: text2sparql
n = 47 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Retrieval, macro (mean per question) | 0.052 | 0.070 | 0.038 | 43 |
| Retrieval, micro (pooled TP=44, FP=1837, FN=633) | 0.023 | 0.065 | 0.034 | 43 |
| Answer tokens vs reference (macro) | 0.259 | 0.306 | 0.255 | 47 |
**4 of 47 answers ended in an error** (a failed generated query is an error too). Most frequent: 3 x GraphDB error 500: Query evaluation error: Unknown function 'http://ww; 1 x SPARQL syntax error: Expected end of text, found 'UNION'  (at char 153


Yes/no answers (text2sparql): abstain 9, yes 4, error 2, no 1  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 8, no 8. Majority baseline (always 'yes'): accuracy 0.500

## Yes/no questions (text2sparql)
n = 16

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.000 | 0.000 | 0.000 | 8 |
| yes | 0.500 | 0.250 | 0.333 | 8 |
| **macro** | 0.250 | 0.125 | 0.167 | 16 |
| **micro** (= accuracy) | 0.125 | 0.125 | 0.125 | 16 |

## Yes/no questions about images (text2sparql)
n = 6

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.000 | 0.000 | 0.000 | 1 |
| yes | 0.000 | 0.000 | 0.000 | 5 |
| **macro** | 0.000 | 0.000 | 0.000 | 6 |
| **micro** (= accuracy) | 0.000 | 0.000 | 0.000 | 6 |

## End-to-end: text2sparql_plus
n = 47 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Retrieval, macro (mean per question) | 0.500 | 0.139 | 0.207 | 36 |
| Retrieval, micro (pooled TP=68, FP=3, FN=481) | 0.958 | 0.124 | 0.219 | 36 |
| Answer tokens vs reference (macro) | 0.246 | 0.259 | 0.236 | 47 |
**11 of 47 answers ended in an error** (a failed generated query is an error too). Most frequent: 11 x query must be a SELECT or ASK query


Yes/no answers (text2sparql_plus): abstain 8, error 6, no 2  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 8, no 8. Majority baseline (always 'yes'): accuracy 0.500

## Yes/no questions (text2sparql_plus)
n = 16

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.500 | 0.125 | 0.200 | 8 |
| yes | 0.000 | 0.000 | 0.000 | 8 |
| **macro** | 0.250 | 0.062 | 0.100 | 16 |
| **micro** (= accuracy) | 0.062 | 0.062 | 0.062 | 16 |

## Yes/no questions about images (text2sparql_plus)
n = 6

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.000 | 0.000 | 0.000 | 1 |
| yes | 0.000 | 0.000 | 0.000 | 5 |
| **macro** | 0.000 | 0.000 | 0.000 | 6 |
| **micro** (= accuracy) | 0.000 | 0.000 | 0.000 | 6 |
