# Precision, recall and F1

## Routing (kg / rag / chitchat)
n = 1001

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| kg | 0.993 | 0.969 | 0.981 | 711 |
| rag | 0.946 | 0.972 | 0.959 | 290 |
| **macro** | 0.970 | 0.971 | 0.970 | 1001 |
| **micro** (= accuracy) | 0.970 | 0.970 | 0.970 | 1001 |

## CQ selection (knowledge-graph questions)
n = 711

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| CQ01 | 1.000 | 1.000 | 1.000 | 7 |
| CQ02 | 0.846 | 0.917 | 0.880 | 24 |
| CQ03 | 1.000 | 0.778 | 0.875 | 9 |
| CQ04 | 0.571 | 0.667 | 0.615 | 6 |
| CQ05 | 0.818 | 0.692 | 0.750 | 13 |
| CQ06 | 0.900 | 0.900 | 0.900 | 10 |
| CQ07 | 1.000 | 0.571 | 0.727 | 7 |
| CQ08 | 0.923 | 0.857 | 0.889 | 14 |
| CQ09 | 1.000 | 0.706 | 0.828 | 17 |
| CQ10 | 0.625 | 1.000 | 0.769 | 10 |
| CQ11 | 0.583 | 0.700 | 0.636 | 10 |
| CQ12 | 0.611 | 0.611 | 0.611 | 18 |
| CQ13 | 0.333 | 0.545 | 0.414 | 11 |
| CQ14 | 0.333 | 0.833 | 0.476 | 30 |
| CQ15 | 0.333 | 0.818 | 0.474 | 11 |
| CQ16 | 0.460 | 0.744 | 0.569 | 39 |
| CQ17 | 0.727 | 0.889 | 0.800 | 18 |
| CQ18 | 0.540 | 0.557 | 0.548 | 61 |
| CQ19 | 0.727 | 0.407 | 0.522 | 59 |
| CQ20 | 0.795 | 0.397 | 0.530 | 78 |
| CQ21 | 0.417 | 0.714 | 0.526 | 14 |
| CQ22 | 0.909 | 0.294 | 0.444 | 68 |
| CQ23 | 0.818 | 0.562 | 0.667 | 16 |
| CQ24 | 0.978 | 0.355 | 0.521 | 124 |
| CQ25 | 1.000 | 0.500 | 0.667 | 10 |
| CQ26 | 0.667 | 0.370 | 0.476 | 27 |
| **macro** | 0.728 | 0.669 | 0.658 | 711 |
| **micro** (= accuracy) | 0.543 | 0.543 | 0.543 | 711 |

## End-to-end: cq
n = 660 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Retrieval, macro (mean per question) | 0.736 | 0.735 | 0.731 | 631 |
| Retrieval, micro (pooled TP=2848, FP=1813, FN=1636) | 0.611 | 0.635 | 0.623 | 631 |
| Answer tokens vs reference (macro) | 0.245 | 0.338 | 0.270 | 660 |
**8 of 660 answers ended in an error** (a failed generated query is an error too). Most frequent: 3 x query must be a SELECT or ASK query; 2 x SPARQL syntax error: Expected SelectQuery, found 'FILTER'  (at char 89


Yes/no answers (cq): no 211, abstain 201, yes 40, error 5  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 326, no 131. Majority baseline (always 'yes'): accuracy 0.713

## Yes/no questions (cq)
n = 457

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.280 | 0.450 | 0.345 | 131 |
| yes | 0.900 | 0.110 | 0.197 | 326 |
| **macro** | 0.590 | 0.280 | 0.271 | 457 |
| **micro** (= accuracy) | 0.208 | 0.208 | 0.208 | 457 |

## Yes/no questions where the KG holds evidence (cq, gold query returned rows)
n = 263

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.263 | 0.797 | 0.395 | 59 |
| yes | 0.923 | 0.176 | 0.296 | 204 |
| **macro** | 0.593 | 0.487 | 0.346 | 263 |
| **micro** (= accuracy) | 0.316 | 0.316 | 0.316 | 263 |

194 yes/no questions have no evidence in the KG at all (the gold query returns 0 rows: the scene/caption/audio extraction did not record it).

## Yes/no questions about images (cq)
n = 447

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.263 | 0.435 | 0.328 | 124 |
| yes | 0.944 | 0.105 | 0.189 | 323 |
| **macro** | 0.604 | 0.270 | 0.259 | 447 |
| **micro** (= accuracy) | 0.197 | 0.197 | 0.197 | 447 |

## End-to-end: cq_fusion
n = 660 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Retrieval, macro (mean per question) | 0.736 | 0.735 | 0.731 | 631 |
| Retrieval, micro (pooled TP=2846, FP=1823, FN=1631) | 0.610 | 0.636 | 0.622 | 631 |
| Answer tokens vs reference (macro) | 0.199 | 0.252 | 0.210 | 660 |
**8 of 660 answers ended in an error** (a failed generated query is an error too). Most frequent: 3 x query must be a SELECT or ASK query; 1 x SPARQL syntax error: Expected SelectQuery, found '('  (at char 539), (


Yes/no answers (cq_fusion): no 377, yes 42, abstain 33, error 5  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 326, no 131. Majority baseline (always 'yes'): accuracy 0.713

## Yes/no questions (cq_fusion)
n = 457

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.300 | 0.863 | 0.445 | 131 |
| yes | 0.881 | 0.113 | 0.201 | 326 |
| **macro** | 0.590 | 0.488 | 0.323 | 457 |
| **micro** (= accuracy) | 0.328 | 0.328 | 0.328 | 457 |

## Yes/no questions where the KG holds evidence (cq_fusion, gold query returned rows)
n = 263

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.261 | 0.915 | 0.406 | 59 |
| yes | 0.925 | 0.181 | 0.303 | 204 |
| **macro** | 0.593 | 0.548 | 0.355 | 263 |
| **micro** (= accuracy) | 0.346 | 0.346 | 0.346 | 263 |

194 yes/no questions have no evidence in the KG at all (the gold query returns 0 rows: the scene/caption/audio extraction did not record it).

## Yes/no questions about images (cq_fusion)
n = 447

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.291 | 0.871 | 0.436 | 124 |
| yes | 0.921 | 0.108 | 0.194 | 323 |
| **macro** | 0.606 | 0.490 | 0.315 | 447 |
| **micro** (= accuracy) | 0.320 | 0.320 | 0.320 | 447 |

## End-to-end: cq_vlm
n = 660 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Retrieval, macro (mean per question) | 0.739 | 0.737 | 0.734 | 633 |
| Retrieval, micro (pooled TP=2848, FP=1813, FN=1633) | 0.611 | 0.636 | 0.623 | 633 |
| Answer tokens vs reference (macro) | 0.199 | 0.254 | 0.211 | 660 |
**7 of 660 answers ended in an error** (a failed generated query is an error too). Most frequent: 3 x query must be a SELECT or ASK query; 1 x SPARQL syntax error: Expected SelectQuery, found '('  (at char 539), (


Yes/no answers (cq_vlm): no 217, yes 200, abstain 35, error 5  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 326, no 131. Majority baseline (always 'yes'): accuracy 0.713

## Yes/no questions (cq_vlm)
n = 457

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.479 | 0.794 | 0.598 | 131 |
| yes | 0.935 | 0.574 | 0.711 | 326 |
| **macro** | 0.707 | 0.684 | 0.654 | 457 |
| **micro** (= accuracy) | 0.637 | 0.637 | 0.637 | 457 |

## Yes/no questions where the KG holds evidence (cq_vlm, gold query returned rows)
n = 263

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.432 | 0.814 | 0.565 | 59 |
| yes | 0.934 | 0.623 | 0.747 | 204 |
| **macro** | 0.683 | 0.718 | 0.656 | 263 |
| **micro** (= accuracy) | 0.665 | 0.665 | 0.665 | 263 |

194 yes/no questions have no evidence in the KG at all (the gold query returns 0 rows: the scene/caption/audio extraction did not record it).

## Yes/no questions about images (cq_vlm)
n = 447

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.469 | 0.798 | 0.591 | 124 |
| yes | 0.944 | 0.573 | 0.713 | 323 |
| **macro** | 0.707 | 0.686 | 0.652 | 447 |
| **micro** (= accuracy) | 0.635 | 0.635 | 0.635 | 447 |

Vision-model check changed 158 answers to 'yes'; 150 of them are 'yes' in the reference.

## End-to-end: vlm
n = 660 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Answer tokens vs reference (macro) | 0.491 | 0.088 | 0.127 | 660 |
**42 of 660 answers ended in an error** (a failed generated query is an error too). Most frequent: 38 x no local image for this record (not an image question, or set IMAGES_D; 4 x Ollama /api/chat failed: 400 {"error":"{\"error\":{\"code\":400,\"mess


Yes/no answers (vlm): no 243, yes 201, error 13  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 326, no 131. Majority baseline (always 'yes'): accuracy 0.713

## Yes/no questions (vlm)
n = 457

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.477 | 0.885 | 0.620 | 131 |
| yes | 0.960 | 0.592 | 0.732 | 326 |
| **macro** | 0.719 | 0.739 | 0.676 | 457 |
| **micro** (= accuracy) | 0.676 | 0.676 | 0.676 | 457 |

## Yes/no questions where the KG holds evidence (vlm, gold query returned rows)
n = 263

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.404 | 0.780 | 0.532 | 59 |
| yes | 0.956 | 0.637 | 0.765 | 204 |
| **macro** | 0.680 | 0.708 | 0.648 | 263 |
| **micro** (= accuracy) | 0.669 | 0.669 | 0.669 | 263 |

194 yes/no questions have no evidence in the KG at all (the gold query returns 0 rows: the scene/caption/audio extraction did not record it).

## Yes/no questions about images (vlm)
n = 447

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.477 | 0.935 | 0.632 | 124 |
| yes | 0.960 | 0.598 | 0.737 | 323 |
| **macro** | 0.719 | 0.767 | 0.684 | 447 |
| **micro** (= accuracy) | 0.691 | 0.691 | 0.691 | 447 |

## End-to-end: text2sparql
n = 660 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Retrieval, macro (mean per question) | 0.400 | 0.395 | 0.393 | 587 |
| Retrieval, micro (pooled TP=53, FP=1337, FN=3644) | 0.038 | 0.014 | 0.021 | 587 |
| Answer tokens vs reference (macro) | 0.224 | 0.293 | 0.244 | 660 |
**52 of 660 answers ended in an error** (a failed generated query is an error too). Most frequent: 19 x query must be a SELECT or ASK query; 10 x only read-only SELECT/ASK queries are allowed


Yes/no answers (text2sparql): abstain 410, error 39, no 6, yes 2  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 326, no 131. Majority baseline (always 'yes'): accuracy 0.713

## Yes/no questions (text2sparql)
n = 457

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.167 | 0.008 | 0.015 | 131 |
| yes | 0.000 | 0.000 | 0.000 | 326 |
| **macro** | 0.083 | 0.004 | 0.007 | 457 |
| **micro** (= accuracy) | 0.002 | 0.002 | 0.002 | 457 |

## Yes/no questions where the KG holds evidence (text2sparql, gold query returned rows)
n = 263

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.333 | 0.017 | 0.032 | 59 |
| yes | 0.000 | 0.000 | 0.000 | 204 |
| **macro** | 0.167 | 0.008 | 0.016 | 263 |
| **micro** (= accuracy) | 0.004 | 0.004 | 0.004 | 263 |

194 yes/no questions have no evidence in the KG at all (the gold query returns 0 rows: the scene/caption/audio extraction did not record it).

## Yes/no questions about images (text2sparql)
n = 447

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.167 | 0.008 | 0.015 | 124 |
| yes | 0.000 | 0.000 | 0.000 | 323 |
| **macro** | 0.083 | 0.004 | 0.008 | 447 |
| **micro** (= accuracy) | 0.002 | 0.002 | 0.002 | 447 |

## End-to-end: text2sparql_plus
n = 660 questions

| Stage | Precision | Recall | F1 | n |
|---|---|---|---|---|
| Retrieval, macro (mean per question) | 0.311 | 0.280 | 0.283 | 586 |
| Retrieval, micro (pooled TP=42, FP=367, FN=4225) | 0.103 | 0.010 | 0.018 | 586 |
| Answer tokens vs reference (macro) | 0.255 | 0.303 | 0.261 | 660 |
**53 of 660 answers ended in an error** (a failed generated query is an error too). Most frequent: 19 x only read-only SELECT/ASK queries are allowed; 2 x SPARQL syntax error: Expected SelectQuery, found 'FILTER'  (at char 69


Yes/no answers (text2sparql_plus): abstain 287, no 134, error 34, yes 2  (abstain = 'the knowledge graph has no information …')
Reference answers: yes 326, no 131. Majority baseline (always 'yes'): accuracy 0.713

## Yes/no questions (text2sparql_plus)
n = 457

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.328 | 0.336 | 0.332 | 131 |
| yes | 0.500 | 0.003 | 0.006 | 326 |
| **macro** | 0.414 | 0.169 | 0.169 | 457 |
| **micro** (= accuracy) | 0.098 | 0.098 | 0.098 | 457 |

## Yes/no questions where the KG holds evidence (text2sparql_plus, gold query returned rows)
n = 263

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.310 | 0.373 | 0.338 | 59 |
| yes | 1.000 | 0.005 | 0.010 | 204 |
| **macro** | 0.655 | 0.189 | 0.174 | 263 |
| **micro** (= accuracy) | 0.087 | 0.087 | 0.087 | 263 |

194 yes/no questions have no evidence in the KG at all (the gold query returns 0 rows: the scene/caption/audio extraction did not record it).

## Yes/no questions about images (text2sparql_plus)
n = 447

| Class | Precision | Recall | F1 | support |
|---|---|---|---|---|
| no | 0.323 | 0.347 | 0.335 | 124 |
| yes | 0.500 | 0.003 | 0.006 | 323 |
| **macro** | 0.412 | 0.175 | 0.170 | 447 |
| **micro** (= accuracy) | 0.098 | 0.098 | 0.098 | 447 |
